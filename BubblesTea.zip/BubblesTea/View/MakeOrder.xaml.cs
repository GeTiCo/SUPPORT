﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;

namespace BubblesTea.View
{
    /// <summary>
    /// Логика взаимодействия для MakeOrder.xaml
    /// </summary>
    public partial class MakeOrder : Window
    {
        List<string> listCat;

        public MakeOrder()
        {
            InitializeComponent();
            makeCategoryList();
        }
        //Переход на главное окно
        private void BackOnMainWindow(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MovePayOrder(object sender, RoutedEventArgs e)
        {
            View.PayOrder payorder = new View.PayOrder();
            this.Hide();
            payorder.ShowDialog();
        }
        //Функция поиска и сбора всех листов из Excel
        private void makeCategoryList()
        {
            listCategory.Items.Clear();
            listCat = new List<string>();

            foreach (Excel.Worksheet item in App.excelWorkBook.Worksheets)
            {
                listCat.Add(item.Name);
            }

            listCategory.ItemsSource = listCat;
        }
    }
}
